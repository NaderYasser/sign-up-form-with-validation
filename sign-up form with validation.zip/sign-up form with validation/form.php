<!DOCTYPE html>
	<html>
	<head>
	 
		 <meta charset="utf-8" />
		 <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
		 <meta name="viewport" content="width=device-width, initial-scale=1">

			  
		  <link rel="stylesheet"  href="css/bootstrap.css">
		  <link rel="stylesheet" type="text/css" href="css/normalize.css">
		  <link rel="stylesheet" type="text/css" href="css/main.css" media="screen">
	 
		<title></title>

	</head>

	<body>

      <div class="container">
        
         <form name="signUp" id="signUp">

           <div>
             <input type="text" id="name" name="name" placeholder="your full name"> 
             <span id="namr-info">what is your name?</span>  
           </div>

              <div>
                <input type="number" id="mobile-number" name="mobile-number" placeholder="phone number ">
              <span id="mobile-info"></span>
           </div>
             
           <div>
             <input type="email" name="mail" id="email" placeholder="e-mail"> 
             <span id="email-info">please type a valid e-mail..</span>  
           </div>
               
           <div>
             <input type="password" name="password" id="password" placeholder="password"> 
             <span id="password-info">password must be more than 5 char</span>  
           </div>
               
           <div>
             <input type="password" id="confirm-password" name="password" placeholder="confirm password"> 
             <span id="confirm-password-info"> please confirm your password</span>  
           </div>
         
             
        
           
           
             <select id="year">
             	<option> study year</option>
             	<option> 1st</option>
             	<option> 2nd</option>
             	<option> 3rd</option>
             	<option> senior</option>
             	<option> e3dady</option>
             </select>
         	 <br>
         	<select id="department">
             	<option> department</option>
             	<option> elec</option>
             	<option> civil</option>
             	<option> arch</option>
             	<option>mecha </option>
             	<option> e3dady</option>
             </select>

             <br><br><br>
             <input type="submit" id="submit"></input>
         	
         </form>
      	
      </div>
    

	 


		<script src="js/jquery-1.12.0.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/script.js"></script> 

	</body>
</html>