$(document).ready(function () {
	
var form = $("#signUp");
var name = $("#name");
var nameInfo = $("#name-info");
var email = $("#email");
var emailInfo = $("#email-info");
var mobile = $("#mobile-number");
var mobileInfo = $("#mobile-info");
var password = $("#password");
var passwordInfo = $("#password-info");
var cpassword = $("#confirm-password");
var cpasswordInfo = $("#confirm-password-info");
var state = false ;



function validateName() {
	 if (name.val().length <= 5) {
        name.removeClass("valid");
        nameInfo.removeClass("valid");
        name.addClass("error");
        nameInfo.addClass("error");
        nameInfo.text("please enter your full name...");
        state = false;

	 }
	 else{

	 	name.removeClass("error");
        nameInfo.removeClass("error");
        name.addClass("valid");
        nameInfo.addClass("valid");
        nameInfo.text("");
        state = true;

	 	  		}
            return state ;	 	  	
	 	  }
	 
function validateNumber() {
	 if (mobile.val().length < 11) {
        mobile.removeClass("valid");
        mobileInfo.removeClass("valid");
        mobile.addClass("error");
        mobileInfo.addClass("error");
        mobileInfo.text("please enter a valid mobile number");
        state = false;

	 }
	 else{

	 	mobile.removeClass("error");
        mobileInfo.removeClass("error");
        mobile.addClass("valid");
        mobileInfo.addClass("valid");
        mobile-infoInfo.text("");
        state = true;

	 	  		}
            return state ;	 	  	
	 	  }




function validateEmail(){
		//testing regular expression
		var a = $("#email").val();
		var filter = /^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+[a-zA-Z0-9_-]+@[a-zA-Z0-9]+[a-zA-Z0-9.-]+[a-zA-Z0-9]+.[a-z]{2,4}$/;
		var uemail = email.val();
		//if it's valid email
		if(filter.test(a)){
				    email.removeClass("error");
					emailInfo.removeClass("error");
					email.addClass("valid");
					emailInfo.addClass("valid");
					emailInfo.text("");
					state = true;
				}
					
		
		//if it's NOT valid
		else{
			email.removeClass("valid");
			emailInfo.removeClass("valid");
			email.addClass("error");
			emailInfo.addClass("error");
			emailInfo.text("Please type a valid e-mail ..");
			state = false;
		}
		return state;
	}


function validatepassword(){
		var a = $("#password1");
		var b = $("#password2");

		//it's NOT valid
		if(password.val().length <5){
			password.removeClass("valid");
			passwordInfo.removeClass("valid");
			password.addClass("error");
			passwordInfo.addClass("error");
			passwordInfo.text("Password must have least 5 characters!");
			state = false;
		}
		//it's valid
		else{
			password.removeClass("error");
			passwordInfo.removeClass("error");
			password.addClass("valid");
			passwordInfo.addClass("valid");
			passwordInfo.text("");
			validatecpassword();
			state = true;
		}
		return state;
	}
	
	function validatecpassword(){
		var a = $("#password1");
		var b = $("#password2");
		//are NOT valid
		if( password.val() != cpassword.val() ){
			cpassword.removeClass("valid");
			cpasswordInfo.removeClass("valid");
			cpassword.addClass("error");
			cpasswordInfo.addClass("error");
			cpasswordInfo.text("Passwords doesn't match!");
			state = false;
		}
		//are valid
		else{
			cpassword.removeClass("error");
			cpasswordInfo.removeClass("error");
			cpassword.addClass("valid");
			cpasswordInfo.addClass("valid");
			cpasswordInfo.text("");
			state = true;
		}
		return state;
	}
	
	name.keyup(validateName);
	email.keyup(validateEmail);
	password.keyup(validatepassword);
	cpassword.keyup(validatecpassword);
	mobile.keyup(validateNumber);
	
	











});