$(document).ready(function () {

 $('body').height($(window).height());
 $('body').width($(window).width());

 $('.container').fadeIn(1500);	

	
	











});