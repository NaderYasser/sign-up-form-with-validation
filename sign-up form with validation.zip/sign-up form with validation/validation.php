<?php

$name = &$_POST['name'];
$email = &$_POST['email'];


if($name!=""){
mysql_connect("localhost", "root", "") or die("We couldn't connect!");
mysql_select_db("testsite");
$username = mysql_query("SELECT name FROM users WHERE name='$name'");
$count = mysql_num_rows($username);
if($count!=0){
	echo "no";
}else{
	echo "yes";
}
}

if($email!=""){
mysql_connect("localhost", "root", "") or die("We couldn't connect!");
mysql_select_db("testsite");
$useremail = mysql_query("SELECT email FROM users WHERE email='$email'");
$ecount = mysql_num_rows($useremail);

if($ecount!=0){
	echo "no";
}else{
	echo "yes";
}
}
	
?>